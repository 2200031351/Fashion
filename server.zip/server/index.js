const express = require('express');
const cors = require('cors');
const { MongoClient } = require('mongodb');
const bcrypt = require('bcrypt');

const app = express();
app.use(express.json());
app.use(cors());
app.get('/home', (req, res) => {
    res.send("-*My Home Page")
})

const client = new MongoClient('mongodb+srv://admin:admin@cluster0.chiwgio.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0');
client.connect();
const db = client.db('mswdsrp');
const col = db.collection('register');

app.post('/insert', async (req, res) => {
    console.log(req.body);
    req.body.password = await bcrypt.hash(req.body.password, 5);
    col.insertOne(req.body);
    res.send("Successfully Received");
});

app.get('/showall', async (req, res) => {
    const result = await col.find().toArray();
    console.log(result);
    res.send(result);
});

app.post('/delete', async (req, res) => {
    const result1 = await col.findOne({ 'name': req.body.un });
    console.log(result1);
    if (result1.password == req.body.pw) {
        col.deleteOne(result1);
        res.send("Successfully deleted");
    } else {
        res.status(400).send("Invalid credentials");
    }
});

app.post('/login', async (req, res) => {
    console.log(req.body);
    const user = await col.findOne({ 'name': req.body.name });
    if (user) {
        const passwordMatch = await bcrypt.compare(req.body.password, user.password);
        if (passwordMatch) {
            res.send("Login Successful");
        } else {
            res.status(400).send("Invalid credentials");
        }
    } else {
        res.status(400).send("User not found");
    }
});

app.listen(5000, () => {
    console.log("Server running on port 5000");
});
